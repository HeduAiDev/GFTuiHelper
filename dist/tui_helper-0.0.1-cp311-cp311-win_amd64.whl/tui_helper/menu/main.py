

print("hello world outside")
print(__name__)

def main():
    print("hello world in main function")
    print(__name__)